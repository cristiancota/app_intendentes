<a class="btn btn-primary" href="javascript:var dir=window.document.URL;var tit=window.document.title;var
                       tit2=encodeURIComponent(tit);var dir2= encodeURIComponent(dir);window.location.
                       href=('http://www.facebook.com/share.php?u='+dir2+'&amp;t='+tit2+'');">
    <i class="fa fa-facebook"></i>
</a>
<a class="btn btn-info  " href="javascript:var dir=window.document.URL;var tit=window.document.title;var tit2=encodeURIComponent(tit);
                       window.location.href=('http://twitter.com/?status='+tit2+'%20'+dir+'');">
    <i class="fa fa-twitter "></i>
</a>
<a class="btn btn-danger" href="javascript:window.location.href='https://plus.google.com/share?url='+encodeURIComponent(location);void0;">
    <i class="fa fa-google-plus"></i>
</a>