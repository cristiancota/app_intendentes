<!-- fancybox -->
<link href="public/assets/Librerias/fancybox/jquery.fancybox.css" rel="stylesheet" type="text/css"/>
<link href="public/assets/Librerias/fancybox/helpers/jquery.fancybox-thumbs.css" rel="stylesheet" type="text/css"/>
<link href="public/assets/Librerias/fancybox/helpers/jquery.fancybox-buttons.css" rel="stylesheet" type="text/css"/>
<!-- gridLoading -->
<link href="public/assets/Librerias/gridLoading/css/component.css" rel="stylesheet" type="text/css"/>