<table class="table table-striped">
    <tbody class="text-center">
    <tr>
        <th>
            Numero Intendente
        </th>
        <th>
            Nombre
        </th>
        <th>
            Apellidos
        </th>
        <th>
            Cel
        </th>

    </tr>

    </tbody>
</table>