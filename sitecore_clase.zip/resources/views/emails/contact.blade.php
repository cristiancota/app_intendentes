
<img src="<?php echo $message->embed("pulsoe.com/public_html/img/interfaz/30.jpg"); ?>">
<p>
 <h1>{{ $name }}</h1>
</p>

<p>
    {{ $email }}
</p>

<p>
    {{ $user_message }}
</p>