<?php
/**
 * Created by PhpStorm.
 * User: alex
 * Date: 08/07/2015
 * Time: 01:37 AM
 */

namespace App\Z;


class sup
{

public static  function test(){
    dd("die");
}


}