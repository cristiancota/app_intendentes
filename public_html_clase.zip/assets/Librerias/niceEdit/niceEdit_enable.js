bkLib.onDomLoaded(function () {
                nicEditors.allTextAreas();
                new nicEditor().panelInstance('Body');
                });