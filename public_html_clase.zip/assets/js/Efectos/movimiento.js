$(document).ready(function(){



if ($(window).width() > 800) {;
 $('.uno').fadeOut(1).fadeIn(1500).animate(
                    {'margin-left' :'600', 'width' : '600' },1000);
            
            
            $('.dos').fadeOut(1).fadeIn(1800).animate(
                    {'margin-left' :'600', 'width' : '600' },800);

            }
});
         