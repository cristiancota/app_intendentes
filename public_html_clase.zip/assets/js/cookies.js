/**
 * Created by alex on 25/07/2015.
 */
function cookieClass ()
{

}

cookieClass.prototype.isSet = FALSE;

cookieClass.prototype.getCookies = function()
{

    this.isSet ? this.isSet :  TRUE;



}